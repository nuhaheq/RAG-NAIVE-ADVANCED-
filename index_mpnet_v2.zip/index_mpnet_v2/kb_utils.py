
import json, re, pickle
import numpy as np

# BM25 tokenizer: lower-case; keep clinical tokens such as 'cha2ds2-vasc', '2.5', 'mg/dl', 'p-gp' intact;
# drop English stop words (scikit-learn list). The same function must be used for queries and documents.
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS
_TOKEN = re.compile(r"[a-z0-9]+(?:[-./][a-z0-9]+)*")
def bm25_tokenize(text):
    return [t for t in _TOKEN.findall(text.lower()) if t not in ENGLISH_STOP_WORDS]

def load_kb(folder):
    import faiss
    chunks = json.load(open(f"{folder}/kb_chunks_indexed.json"))
    index = faiss.read_index(f"{folder}/faiss_mpnet.index")
    bm25 = pickle.load(open(f"{folder}/bm25.pkl", "rb"))
    return chunks, index, bm25

def dense_search(query, model, index, k=10):
    q = model.encode([query], normalize_embeddings=True, convert_to_numpy=True).astype("float32")
    scores, rows = index.search(q, k)
    return [(int(r), float(s)) for r, s in zip(rows[0], scores[0]) if r >= 0]

def bm25_search(query, bm25, k=10):
    scores = bm25.get_scores(bm25_tokenize(query))
    top = np.argsort(-scores)[:k]
    return [(int(r), float(scores[r])) for r in top]

def rrf(*rankings, k_rrf=60, top_n=10):
    # Reciprocal Rank Fusion (Cormack et al., 2009): score = sum 1/(k_rrf + rank), rank starting at 1
    fused = {}
    for ranking in rankings:
        for rank, (row, _) in enumerate(ranking, start=1):
            fused[row] = fused.get(row, 0.0) + 1.0 / (k_rrf + rank)
    return sorted(fused.items(), key=lambda x: -x[1])[:top_n]
